source("../functions.R")

# Data wrangling
wrangling <- c("tidyverse", "data.table","reshape2", "scales", "gridExtra", "directlabels", 'parallel')

library2(wrangling)
