source("../functions.R")

# Data wrangling
wrangling <- c("tidyverse", "scales")

library2(wrangling)








