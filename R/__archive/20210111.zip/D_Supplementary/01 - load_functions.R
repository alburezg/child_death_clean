source("../functions.R")

# Data wrangling
wrangling <- c("tidyverse", "scales", "knitr", "kableExtra", "maps", "countrycode", "viridis", "rworldmap", "patchwork")

library2(wrangling)
