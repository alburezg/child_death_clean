source("../functions.R")

# Data wrangling
wrangling <- c("tidyverse", "scales", "maps", "countrycode", "viridis", "rworldmap", "ggrepel", "patchwork")

library2(wrangling)
